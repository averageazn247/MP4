

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include "Semaphore.c"
using namespace std;
